import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
class HomePagePhone extends StatelessWidget {
  const HomePagePhone({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: ListView(
        children: [
          Container(
            padding: const EdgeInsets.all(20),
            child: Text(
              "My favorite movies and series",
              style: GoogleFonts.notoSans(fontSize: 30),
            ),
          ),
          Column(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _card(
                  "https://p2.trrsf.com/image/fget/cf/940/0/images.terra.com/2022/08/19/a-casa-do-dragao-hbo-max-ubu71gdzdrae.jpg",
                  "Casa do Dragão"),
              _card(
                  "https://images-na.ssl-images-amazon.com/images/I/81iZ0r1HvmL.jpg",
                  "Game Of Thrones"),
              _card(
                  "https://files.tecnoblog.net/wp-content/uploads/2020/12/ordem-filmes-harry-potter-e1609427898909.jpg",
                  "Harry Potter")
            ],
          ),
          Column(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _card(
                  "https://files.tecnoblog.net/wp-content/uploads/2020/01/the-witcher-netflix.jpg",
                  "The Witcher"),
              _card("https://lumiere-a.akamaihd.net/v1/images/zootopia_-_all_new_first_look5_dead57cb.jpeg?region=63,0,1674,942&width=960", "Zootopia"),
              _card("https://static1.purebreak.com.br/articles/6/91/99/6/@/353530-voce-nao-vai-acreditar-nestas-20-curiosi-diapo-2.jpg", "Alice no país das maravilhas")
            ],
          ),
        ],
      ),
    );
  }
}

_card(image, texto) {
  return Card(
    color: Colors.blue[50],
    child: Column(
      mainAxisAlignment: MainAxisAlignment.start,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          width: 400,
          height: 400,
          decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(18),
              image: DecorationImage(
                fit: BoxFit.cover,
                image: NetworkImage(image),
              )),
        ),
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: Text(
            texto,
            style: GoogleFonts.notoSans(fontSize: 20),
          ),
        ),
      ],
    ),
  );
}