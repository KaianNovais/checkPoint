import 'package:flutter/material.dart';

class Controller extends ChangeNotifier {
  final _nome = "Kaian";
  final _senha = "123";
  String get nome => _nome;
  String get senha => _senha;

  incNumber(){}

}