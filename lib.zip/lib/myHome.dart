import 'package:fiap_provider/Controller/controller.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class MyHomePage extends StatelessWidget {
  const MyHomePage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Provider"),
      ),
      body: Column(
        children: [
          Consumer<Controller>(
            builder: (context, value, __) {
              return Text(value.nome);
            },
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Provider.of<Controller>(context, listen: false).incNumber();
        },
        child: const Icon(Icons.add),
      ),
    );
  }
}
