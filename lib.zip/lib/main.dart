import 'package:fiap_provider/Controller/controller.dart';
import 'package:fiap_provider/Phone/homePagePhone.dart';
import 'package:fiap_provider/Phone/loginPhone.dart';
import 'package:fiap_provider/Tablet/homePageTablet.dart';
import 'package:fiap_provider/Tablet/loginTablet.dart';
import 'package:fiap_provider/Web/homePageWeb.dart';
import 'package:fiap_provider/Web/loginWeb.dart';
import 'package:fiap_provider/myHome.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:responsive_builder/responsive_builder.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.purple,
        scaffoldBackgroundColor: Colors.blue[50] ,
        useMaterial3: true
      ),
      home: ChangeNotifierProvider(
        child: ScreenTypeLayout(
            mobile: const LoginPhome(),
            tablet: const LoginTablet(),
        desktop:  LoginWeb(),
      ),
        create: (_)=>Controller(),
      ),
      routes: {
        "homeWeb": (context)=> const HomePageWeb(),
        "homeTablet": (context)=> const HomePageTablet(),
        "loginPhone": (context)=> const HomePagePhone(),
      },
    );
  }
}