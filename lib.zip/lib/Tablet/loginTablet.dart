import 'package:fiap_provider/Controller/controller.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
class LoginTablet extends StatefulWidget {
  const LoginTablet({Key? key}) : super(key: key);

  @override
  State<LoginTablet> createState() => _LoginTabletState();
}

class _LoginTabletState extends State<LoginTablet> {
  final user = TextEditingController();

  final password = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: ListView(
        children: [
          const SizedBox(height: 30),
          Center(
            child: Text("My favorite movies and series", style: GoogleFonts.aclonica(fontSize: 30), ),
          ),
          const SizedBox(height: 30),
          Column(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              Container(
                padding: const EdgeInsets.all(40),
                width: 600,
                height: 600,
                child: Form(
                  child: Column(
                    children: [
                      Text(
                        "Login",
                        style: GoogleFonts.notoSans(fontSize: 30, fontWeight: FontWeight.bold ),
                      ),
                      const SizedBox(height: 30),
                      _textForm(user, "Nome", false),
                      const SizedBox(height: 30),
                      _textForm(password, "Senha", true),
                      const SizedBox(height: 30),
                      SizedBox(
                        width: 200,
                        child: Consumer<Controller>(
                          builder: (context, value, __) {
                            return ElevatedButton(
                              style: ElevatedButton.styleFrom(
                                  primary: Colors.black),
                              onPressed: () {
                                String nome = user.text;
                                String senha = password.text;
                                if (nome == value.nome &&
                                    senha == value.senha) {
                                  Navigator.of(context).pushNamed("homeTablet");
                                } else {
                                  showDialog(
                                    context: context,
                                    builder: (context) {
                                      return AlertDialog(
                                        title: const Text("Senha inválida"),
                                        actions: [
                                          TextButton(
                                            child: const Text('Ok'),
                                            onPressed: () {
                                              Navigator.of(context).pop();
                                              setState(() {
                                                user.text = "";
                                                password.text = "";
                                              });
                                            },
                                          ),
                                        ],
                                      );
                                    },
                                  );
                                }
                              },
                              child: Text(
                                "Entrar",
                                style: GoogleFonts.aBeeZee(
                                    fontSize: 20, color: Colors.white),
                              ),
                            );
                          },
                        ),
                      )
                    ],
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

_textForm(controller, txt, bool boole) {
  return TextField(
    obscureText: boole,
    controller: controller,
    decoration: InputDecoration(
      hintText: txt,
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(5),
        borderSide: const BorderSide(
          color: Colors.black,
          width: 1.0,
        ),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(8),
        borderSide: const BorderSide(
          color: Colors.purple,
          width: 2.0,
        ),
      ),
    ),
  );
}

